"""
Unit tests for Order Lambda function.

Tests the Lambda function independently without requiring AWS infrastructure,
including tenant isolation checks.
"""

import json
import sys
import os
from unittest.mock import Mock, patch, MagicMock
import pytest

# Add this directory and shared layer to path for imports
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))

# Import the module under test
import index
import lambda_base


class TestOrderLambda:
    """Test suite for Order Lambda function."""
    
    @pytest.fixture
    def mock_table(self):
        """Mock DynamoDB table."""
        with patch('index.table') as mock:
            yield mock
    
    @pytest.fixture
    def mock_logger(self):
        """Mock structured logger."""
        logger = Mock()
        logger.info = Mock()
        logger.debug = Mock()
        logger.error = Mock()
        logger.warning = Mock()
        return logger
    
    @pytest.fixture
    def sample_product(self):
        """Sample product data."""
        return {
            'tenantId': 'test-tenant',
            'productId': 'prod-001',
            'name': 'Test Product',
            'price': 99.99,
            'currency': 'USD'
        }
    
    @pytest.fixture
    def sample_order(self):
        """Sample order data."""
        return {
            'PK': 'TENANT#test-tenant#ORDER',
            'SK': 'ORDER#order-001',
            'orderId': 'order-001',
            'tenantId': 'test-tenant',
            'customerId': 'cust-123',
            'productId': 'prod-001',
            'quantity': 2,
            'totalPrice': 199.98,
            'currency': 'USD',
            'status': 'PENDING',
            'createdAt': '2024-01-15T10:00:00Z',
            'updatedAt': '2024-01-15T10:00:00Z'
        }
    
    @pytest.fixture
    def valid_order_data(self):
        """Valid order request data."""
        return {
            'customerId': 'cust-123',
            'productId': 'prod-001',
            'quantity': 2
        }
    
    def test_validate_order_success(self, valid_order_data):
        """Test order validation with valid data."""
        # Should not raise any exception
        index.validate_order(valid_order_data)
    
    def test_validate_order_missing_field(self):
        """Test order validation with missing required field."""
        order_data = {
            'customerId': 'cust-123',
            'quantity': 2
            # Missing productId
        }
        
        with pytest.raises(ValueError, match='Missing required field: productId'):
            index.validate_order(order_data)
    
    def test_validate_order_invalid_quantity(self):
        """Test order validation with invalid quantity."""
        # Negative quantity
        order_data = {
            'customerId': 'cust-123',
            'productId': 'prod-001',
            'quantity': -1
        }
        
        with pytest.raises(ValueError, match='Quantity must be a positive integer'):
            index.validate_order(order_data)
        
        # Zero quantity
        order_data['quantity'] = 0
        with pytest.raises(ValueError, match='Quantity must be a positive integer'):
            index.validate_order(order_data)
        
        # Non-integer quantity
        order_data['quantity'] = 'two'
        with pytest.raises(ValueError, match='Quantity must be an integer'):
            index.validate_order(order_data)
    
    def test_validate_order_invalid_customer_id(self):
        """Test order validation with invalid customer ID."""
        order_data = {
            'customerId': '',
            'productId': 'prod-001',
            'quantity': 1
        }
        
        with pytest.raises(ValueError, match='Invalid customerId'):
            index.validate_order(order_data)
    
    def test_get_product_success(self, mock_table, mock_logger, sample_product):
        """Test retrieving a product for order validation."""
        # Setup
        mock_table.get_item.return_value = {'Item': sample_product}
        
        # Execute
        result = index.get_product('test-tenant', 'prod-001', mock_logger)
        
        # Verify
        assert result['productId'] == 'prod-001'
        assert result['price'] == 99.99
    
    def test_get_product_not_found(self, mock_table, mock_logger):
        """Test retrieving a product that doesn't exist."""
        # Setup
        mock_table.get_item.return_value = {}
        
        # Execute & Verify
        with pytest.raises(ValueError, match='Product prod-999 not found'):
            index.get_product('test-tenant', 'prod-999', mock_logger)
    
    @patch('index.uuid.uuid4')
    @patch('index.get_product')
    def test_create_order_success(self, mock_get_product, mock_uuid, mock_table, mock_logger, valid_order_data, sample_product):
        """Test creating an order with valid data."""
        # Setup
        mock_uuid.return_value = Mock(hex='order-123')
        mock_uuid.return_value.__str__ = Mock(return_value='order-123')
        mock_get_product.return_value = sample_product
        mock_table.put_item.return_value = {}
        
        # Execute
        result = index.create_order('test-tenant', valid_order_data, mock_logger)
        
        # Verify
        assert result['orderId'] == 'order-123'
        assert result['customerId'] == 'cust-123'
        assert result['productId'] == 'prod-001'
        assert result['quantity'] == 2
        assert result['totalPrice'] == 199.98
        assert result['status'] == 'PENDING'
        mock_table.put_item.assert_called_once()
    
    def test_create_order_invalid_data(self, mock_table, mock_logger):
        """Test creating an order with invalid data."""
        invalid_data = {
            'customerId': 'cust-123',
            'quantity': 2
            # Missing productId
        }
        
        with pytest.raises(ValueError, match='Missing required field'):
            index.create_order('test-tenant', invalid_data, mock_logger)
    
    @patch('index.get_product')
    def test_create_order_product_not_found(self, mock_get_product, mock_table, mock_logger, valid_order_data):
        """Test creating an order with non-existent product."""
        # Setup
        mock_get_product.side_effect = ValueError('Product prod-001 not found')
        
        # Execute & Verify
        with pytest.raises(ValueError, match='Product prod-001 not found'):
            index.create_order('test-tenant', valid_order_data, mock_logger)
    
    def test_get_order_success(self, mock_table, mock_logger, sample_order):
        """Test retrieving a specific order."""
        # Setup
        mock_table.get_item.return_value = {'Item': sample_order}
        
        # Execute
        result = index.get_order('test-tenant', 'order-001', mock_logger)
        
        # Verify
        assert result['orderId'] == 'order-001'
        assert result['customerId'] == 'cust-123'
        assert result['quantity'] == 2
        mock_table.get_item.assert_called_once()
    
    def test_get_order_not_found(self, mock_table, mock_logger):
        """Test retrieving an order that doesn't exist."""
        # Setup
        mock_table.get_item.return_value = {}
        
        # Execute & Verify
        with pytest.raises(ValueError, match='Order order-999 not found'):
            index.get_order('test-tenant', 'order-999', mock_logger)
    
    def test_get_order_invalid_id(self, mock_table, mock_logger):
        """Test retrieving an order with invalid ID."""
        # Execute & Verify
        with pytest.raises(ValueError, match='Invalid order ID format'):
            index.get_order('test-tenant', '', mock_logger)
        
        with pytest.raises(ValueError, match='Invalid order ID format'):
            index.get_order('test-tenant', None, mock_logger)
    
    def test_get_order_cross_tenant_access(self, mock_table, mock_logger, sample_order):
        """Test that cross-tenant access is blocked."""
        # Setup - order belongs to tenant-a but JWT is for tenant-b
        sample_order['tenantId'] = 'tenant-a'
        mock_table.get_item.return_value = {'Item': sample_order}
        
        # Execute & Verify - should raise TenantIsolationError
        with pytest.raises(lambda_base.TenantIsolationError) as exc:
            index.get_order('tenant-b', 'order-001', mock_logger)
        
        assert 'Access denied' in str(exc.value)
        
        # Verify security violation was logged
        mock_logger.warning.assert_called_once()
        call_args = mock_logger.warning.call_args
        assert 'SECURITY VIOLATION' in call_args[0][0]
    
    @patch('index.get_product')
    def test_create_order_cross_tenant_product(self, mock_get_product, mock_table, mock_logger, valid_order_data, sample_product):
        """Test that creating an order with a product from another tenant is blocked."""
        # Setup - product belongs to tenant-a but JWT is for tenant-b
        sample_product['tenantId'] = 'tenant-a'
        mock_get_product.side_effect = lambda_base.TenantIsolationError('Access denied')
        
        # Execute & Verify
        with pytest.raises(lambda_base.TenantIsolationError):
            index.create_order('tenant-b', valid_order_data, mock_logger)
    
    def test_transform_order(self, sample_order):
        """Test order transformation."""
        result = index.transform_order(sample_order)
        
        assert result['orderId'] == 'order-001'
        assert result['customerId'] == 'cust-123'
        assert result['quantity'] == 2
        assert 'PK' not in result
        assert 'SK' not in result
    
    @patch('lambda_base.xray_recorder')
    @patch('index.create_order')
    def test_lambda_handler_create_order(self, mock_create_order, mock_xray, sample_order):
        """Test Lambda handler for creating an order."""
        # Setup
        mock_create_order.return_value = index.transform_order(sample_order)
        
        event = {
            'httpMethod': 'POST',
            'pathParameters': None,
            'body': json.dumps({
                'customerId': 'cust-123',
                'productId': 'prod-001',
                'quantity': 2
            }),
            'requestContext': {
                'requestId': 'test-request-123',
                'httpMethod': 'POST',
                'path': '/orders',
                'authorizer': {
                    'tenant_id': 'test-tenant'
                },
                'identity': {
                    'sourceIp': '192.168.1.1'
                }
            }
        }
        context = Mock()
        
        # Execute
        result = index.lambda_handler(event, context)
        
        # Verify
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert 'data' in body
        assert body['data']['orderId'] == 'order-001'
    
    @patch('lambda_base.xray_recorder')
    @patch('index.get_order')
    def test_lambda_handler_get_order(self, mock_get_order, mock_xray, sample_order):
        """Test Lambda handler for getting a specific order."""
        # Setup
        mock_get_order.return_value = index.transform_order(sample_order)
        
        event = {
            'httpMethod': 'GET',
            'pathParameters': {'orderId': 'order-001'},
            'requestContext': {
                'requestId': 'test-request-123',
                'httpMethod': 'GET',
                'path': '/orders/order-001',
                'authorizer': {
                    'tenant_id': 'test-tenant'
                },
                'identity': {
                    'sourceIp': '192.168.1.1'
                }
            }
        }
        context = Mock()
        
        # Execute
        result = index.lambda_handler(event, context)
        
        # Verify
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert 'data' in body
        assert body['data']['orderId'] == 'order-001'


    def test_get_all_orders_success(self, mock_table, mock_logger, sample_order):
        """Test retrieving all orders for a tenant."""
        mock_table.query.return_value = {'Items': [sample_order]}

        result = index.get_all_orders('test-tenant', mock_logger)

        assert len(result) == 1
        assert result[0]['orderId'] == 'order-001'
        assert 'PK' not in result[0]
        mock_table.query.assert_called_once_with(
            KeyConditionExpression='PK = :pk',
            ExpressionAttributeValues={':pk': 'TENANT#test-tenant#ORDER'}
        )

    def test_get_all_orders_empty(self, mock_table, mock_logger):
        """Test retrieving orders when none exist."""
        mock_table.query.return_value = {'Items': []}

        result = index.get_all_orders('test-tenant', mock_logger)

        assert result == []

    def test_get_all_orders_dynamo_error(self, mock_table, mock_logger):
        """Test get_all_orders when DynamoDB raises an error."""
        mock_table.query.side_effect = Exception('DynamoDB error')

        with pytest.raises(Exception, match='DynamoDB error'):
            index.get_all_orders('test-tenant', mock_logger)

    @patch('lambda_base.xray_recorder')
    @patch('index.get_all_orders')
    def test_lambda_handler_list_orders(self, mock_get_all_orders, mock_xray, sample_order):
        """Test Lambda handler for listing all orders."""
        mock_get_all_orders.return_value = [index.transform_order(sample_order)]

        event = {
            'httpMethod': 'GET',
            'pathParameters': None,
            'requestContext': {
                'requestId': 'test-request-123',
                'httpMethod': 'GET',
                'path': '/orders',
                'authorizer': {
                    'tenant_id': 'test-tenant'
                },
                'identity': {
                    'sourceIp': '192.168.1.1'
                }
            }
        }
        context = Mock()

        result = index.lambda_handler(event, context)

        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert 'data' in body
        assert body['data']['count'] == 1
        assert len(body['data']['orders']) == 1
        assert body['data']['orders'][0]['orderId'] == 'order-001'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
