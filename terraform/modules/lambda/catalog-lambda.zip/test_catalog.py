"""
Unit tests for Catalog Lambda function.

Tests the Lambda function independently without requiring AWS infrastructure,
including tenant isolation checks.
"""

import json
import sys
import os
from unittest.mock import Mock, patch, MagicMock
import pytest

# Add this directory and shared layer to path for imports
sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'shared'))

# Import the module under test
import index
import lambda_base


class TestCatalogLambda:
    """Test suite for Catalog Lambda function."""
    
    @pytest.fixture
    def mock_table(self):
        """Mock DynamoDB table."""
        with patch('index.table') as mock:
            yield mock
    
    @pytest.fixture
    def mock_logger(self):
        """Mock structured logger."""
        logger = Mock()
        logger.info = Mock()
        logger.debug = Mock()
        logger.error = Mock()
        logger.warning = Mock()
        return logger
    
    @pytest.fixture
    def sample_product(self):
        """Sample product data."""
        return {
            'PK': 'TENANT#test-tenant#PRODUCT',
            'SK': 'PRODUCT#prod-001',
            'tenantId': 'test-tenant',
            'productId': 'prod-001',
            'name': 'Test Product',
            'description': 'A test product',
            'price': 99.99,
            'currency': 'USD',
            'category': 'Electronics',
            'inStock': True,
            'createdAt': '2024-01-15T10:00:00Z',
            'updatedAt': '2024-01-15T10:00:00Z'
        }
    
    def test_get_all_products_success(self, mock_table, mock_logger, sample_product):
        """Test retrieving all products for a tenant."""
        # Setup
        mock_table.query.return_value = {
            'Items': [sample_product]
        }
        
        # Execute
        result = index.get_all_products('test-tenant', mock_logger)
        
        # Verify
        assert len(result) == 1
        assert result[0]['productId'] == 'prod-001'
        assert result[0]['name'] == 'Test Product'
        mock_table.query.assert_called_once()
        mock_logger.info.assert_called()
    
    def test_get_all_products_empty(self, mock_table, mock_logger):
        """Test retrieving products when catalog is empty."""
        # Setup
        mock_table.query.return_value = {'Items': []}
        
        # Execute
        result = index.get_all_products('test-tenant', mock_logger)
        
        # Verify
        assert len(result) == 0
        mock_table.query.assert_called_once()
    
    def test_get_product_success(self, mock_table, mock_logger, sample_product):
        """Test retrieving a specific product."""
        # Setup
        mock_table.get_item.return_value = {'Item': sample_product}
        
        # Execute
        result = index.get_product('test-tenant', 'prod-001', mock_logger)
        
        # Verify
        assert result['productId'] == 'prod-001'
        assert result['name'] == 'Test Product'
        assert result['price'] == 99.99
        mock_table.get_item.assert_called_once()
    
    def test_get_product_not_found(self, mock_table, mock_logger):
        """Test retrieving a product that doesn't exist."""
        # Setup
        mock_table.get_item.return_value = {}
        
        # Execute & Verify
        with pytest.raises(ValueError, match='Product prod-999 not found'):
            index.get_product('test-tenant', 'prod-999', mock_logger)
    
    def test_get_product_invalid_id(self, mock_table, mock_logger):
        """Test retrieving a product with invalid ID."""
        # Execute & Verify
        with pytest.raises(ValueError, match='Invalid product ID format'):
            index.get_product('test-tenant', '', mock_logger)
        
        with pytest.raises(ValueError, match='Invalid product ID format'):
            index.get_product('test-tenant', None, mock_logger)
    
    def test_get_product_cross_tenant_access(self, mock_table, mock_logger, sample_product):
        """Test that cross-tenant access is blocked."""
        # Setup - product belongs to tenant-a but JWT is for tenant-b
        sample_product['tenantId'] = 'tenant-a'
        mock_table.get_item.return_value = {'Item': sample_product}
        
        # Execute & Verify - should raise TenantIsolationError
        with pytest.raises(lambda_base.TenantIsolationError) as exc:
            index.get_product('tenant-b', 'prod-001', mock_logger)
        
        assert 'Access denied' in str(exc.value)
        
        # Verify security violation was logged
        mock_logger.warning.assert_called_once()
        call_args = mock_logger.warning.call_args
        assert 'SECURITY VIOLATION' in call_args[0][0]
    
    def test_transform_product(self, sample_product):
        """Test product transformation."""
        result = index.transform_product(sample_product)
        
        assert result['productId'] == 'prod-001'
        assert result['name'] == 'Test Product'
        assert result['price'] == 99.99
        assert 'PK' not in result
        assert 'SK' not in result
    
    @patch('lambda_base.xray_recorder')
    @patch('index.get_all_products')
    def test_lambda_handler_list_products(self, mock_get_all, mock_xray, sample_product):
        """Test Lambda handler for listing products."""
        # Setup
        mock_get_all.return_value = [
            index.transform_product(sample_product)
        ]
        
        event = {
            'httpMethod': 'GET',
            'pathParameters': None,
            'requestContext': {
                'requestId': 'test-request-123',
                'httpMethod': 'GET',
                'path': '/catalog',
                'authorizer': {
                    'tenant_id': 'test-tenant'
                },
                'identity': {
                    'sourceIp': '192.168.1.1'
                }
            }
        }
        context = Mock()
        
        # Execute
        result = index.lambda_handler(event, context)
        
        # Verify
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert 'data' in body
        assert body['data']['count'] == 1
        assert body['tenantId'] == 'test-tenant'
    
    @patch('lambda_base.xray_recorder')
    @patch('index.get_product')
    def test_lambda_handler_get_product(self, mock_get_product, mock_xray, sample_product):
        """Test Lambda handler for getting a specific product."""
        # Setup
        mock_get_product.return_value = index.transform_product(sample_product)
        
        event = {
            'httpMethod': 'GET',
            'pathParameters': {'productId': 'prod-001'},
            'requestContext': {
                'requestId': 'test-request-123',
                'httpMethod': 'GET',
                'path': '/catalog/prod-001',
                'authorizer': {
                    'tenant_id': 'test-tenant'
                },
                'identity': {
                    'sourceIp': '192.168.1.1'
                }
            }
        }
        context = Mock()
        
        # Execute
        result = index.lambda_handler(event, context)
        
        # Verify
        assert result['statusCode'] == 200
        body = json.loads(result['body'])
        assert 'data' in body
        assert body['data']['productId'] == 'prod-001'


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
